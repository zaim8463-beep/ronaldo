package com.example.touchassist

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** أيقونات بخطوط/تعبئة (قريبة من أيقونات قايمة AssistiveTouch). كل أيقونة مرسومة على شبكة 100×100. */
class IconView(ctx: Context, var icon: String) : View(ctx) {

    var tint: Int = Color.WHITE

    private val st = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeWidth = 5f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fl = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }
    private val dark = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#2C2C2E")
    }
    private val rect = RectF()

    private fun rr(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, p: Paint) {
        rect.set(l, t, r, b)
        c.drawRoundRect(rect, rad, rad, p)
    }

    private fun arc(c: Canvas, l: Float, t: Float, r: Float, b: Float, start: Float, sweep: Float) {
        rect.set(l, t, r, b)
        c.drawArc(rect, start, sweep, false, st)
    }

    override fun onDraw(c: Canvas) {
        val s = min(width, height).toFloat()
        if (s <= 0f) return
        c.save()
        c.translate((width - s) / 2f, (height - s) / 2f)
        c.scale(s / 100f, s / 100f)
        st.color = tint
        st.strokeWidth = 5f
        fl.color = tint
        drawIcon(c, icon)
        c.restore()
    }

    private fun star(c: Canvas) {
        val path = Path()
        for (i in 0 until 10) {
            val r = if (i % 2 == 0) 40f else 17f
            val a = -PI / 2 + i * PI / 5
            val x = 50f + r * cos(a).toFloat()
            val y = 54f + r * sin(a).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        c.drawPath(path, fl)
    }

    private fun arrowUp(c: Canvas, x: Float, y1: Float, y2: Float) {
        c.drawLine(x, y1, x, y2, st)
        c.drawLine(x - 12f, y2 + 12f, x, y2, st)
        c.drawLine(x + 12f, y2 + 12f, x, y2, st)
    }

    private fun drawIcon(c: Canvas, id: String) {
        when {
            id.startsWith("swipe:") -> {
                val p = id.split(":")
                drawSwipe(c, p.getOrElse(1) { "1" }.toIntOrNull() ?: 1, p.getOrElse(2) { "up" })
            }
            id.startsWith("fingers:") -> drawFingers(c, id.substring(8).toIntOrNull() ?: 1)
            id.startsWith("g:") -> star(c)
            else -> when (id) {
                "home" -> {
                    st.alpha = 170
                    c.drawCircle(50f, 50f, 37f, st)
                    st.alpha = 255
                    c.drawCircle(50f, 50f, 25f, fl)
                }
                "notifications" -> {
                    val b = Path()
                    b.moveTo(50f, 14f)
                    b.cubicTo(32f, 14f, 28f, 32f, 28f, 50f)
                    b.lineTo(18f, 68f); b.lineTo(82f, 68f); b.lineTo(72f, 50f)
                    b.cubicTo(72f, 32f, 68f, 14f, 50f, 14f)
                    b.close()
                    c.drawPath(b, fl)
                    c.drawCircle(50f, 79f, 8f, fl)
                }
                "control" -> {
                    rr(c, 12f, 18f, 88f, 44f, 13f, fl)
                    c.drawCircle(30f, 31f, 8f, dark)
                    st.strokeWidth = 4.5f
                    rr(c, 12f, 56f, 88f, 82f, 13f, st)
                    c.drawCircle(70f, 69f, 8f, fl)
                }
                "siri" -> {
                    fl.color = Color.argb(190, 255, 45, 85)
                    c.drawCircle(42f, 44f, 24f, fl)
                    fl.color = Color.argb(190, 94, 92, 230)
                    c.drawCircle(60f, 50f, 24f, fl)
                    fl.color = Color.argb(190, 10, 132, 255)
                    c.drawCircle(48f, 62f, 24f, fl)
                    fl.color = tint
                }
                "custom" -> star(c)
                "device" -> {
                    st.strokeWidth = 3.8f
                    rr(c, 31f, 8f, 69f, 92f, 10f, st)
                    c.drawLine(44f, 17f, 56f, 17f, st)
                }
                "lock" -> {
                    rr(c, 24f, 46f, 76f, 84f, 8f, st)
                    arc(c, 34f, 16f, 66f, 76f, 180f, 180f)
                    c.drawCircle(50f, 65f, 4f, fl)
                }
                "rotate" -> {
                    arc(c, 20f, 20f, 80f, 80f, 300f, 250f)
                    c.drawLine(74f, 24f, 78f, 40f, st)
                    c.drawLine(74f, 24f, 60f, 30f, st)
                    rr(c, 40f, 36f, 60f, 64f, 4f, st)
                }
                "lock_rotation" -> {
                    arc(c, 18f, 18f, 82f, 82f, 300f, 250f)
                    c.drawLine(76f, 22f, 80f, 40f, st)
                    c.drawLine(76f, 22f, 60f, 28f, st)
                    rr(c, 38f, 46f, 62f, 66f, 4f, st)
                    arc(c, 42f, 34f, 58f, 58f, 180f, 180f)
                }
                "vol_up", "vol_down" -> {
                    val sp = Path()
                    sp.moveTo(16f, 40f); sp.lineTo(30f, 40f); sp.lineTo(46f, 26f)
                    sp.lineTo(46f, 74f); sp.lineTo(30f, 60f); sp.lineTo(16f, 60f); sp.close()
                    c.drawPath(sp, st)
                    arc(c, 40f, 36f, 64f, 64f, -50f, 100f)
                    if (id == "vol_up") arc(c, 36f, 24f, 78f, 76f, -50f, 100f)
                }
                "mute" -> {
                    val b = Path()
                    b.moveTo(50f, 22f)
                    b.cubicTo(34f, 22f, 30f, 38f, 30f, 52f)
                    b.lineTo(22f, 66f); b.lineTo(78f, 66f); b.lineTo(70f, 52f)
                    b.cubicTo(70f, 38f, 66f, 22f, 50f, 22f)
                    b.close()
                    c.drawPath(b, st)
                    arc(c, 42f, 62f, 58f, 80f, 0f, 180f)
                    c.drawLine(18f, 18f, 82f, 82f, st)
                }
                "more" -> {
                    c.drawCircle(24f, 50f, 7f, fl)
                    c.drawCircle(50f, 50f, 7f, fl)
                    c.drawCircle(76f, 50f, 7f, fl)
                }
                "screenshot" -> {
                    val corners = floatArrayOf(
                        20f, 36f, 20f, 20f, 20f, 20f, 36f, 20f,
                        64f, 20f, 80f, 20f, 80f, 20f, 80f, 36f,
                        80f, 64f, 80f, 80f, 80f, 80f, 64f, 80f,
                        36f, 80f, 20f, 80f, 20f, 80f, 20f, 64f
                    )
                    c.drawLines(corners, st)
                    c.drawCircle(50f, 50f, 9f, st)
                }
                "recents" -> {
                    rr(c, 14f, 34f, 64f, 78f, 8f, st)
                    rr(c, 36f, 22f, 86f, 66f, 8f, st)
                }
                "restart" -> {
                    arc(c, 22f, 26f, 78f, 82f, -55f, 290f)
                    c.drawLine(50f, 14f, 50f, 48f, st)
                }
                "multitask" -> {
                    rr(c, 16f, 20f, 84f, 80f, 8f, st)
                    c.drawLine(50f, 20f, 50f, 80f, st)
                }
                "gestures" -> {
                    c.drawCircle(28f, 36f, 10f, st)
                    c.drawCircle(72f, 36f, 10f, st)
                    c.drawCircle(50f, 68f, 10f, st)
                }
                "chev" -> {
                    st.strokeWidth = 8f
                    val p = Path()
                    p.moveTo(62f, 20f); p.lineTo(32f, 50f); p.lineTo(62f, 80f)
                    c.drawPath(p, st)
                }
                "back" -> {
                    val p = Path()
                    p.moveTo(68f, 22f); p.lineTo(28f, 50f); p.lineTo(68f, 78f); p.close()
                    c.drawPath(p, st)
                }
                "newgesture", "plus" -> {
                    st.strokeWidth = 7f
                    c.drawLine(50f, 22f, 50f, 78f, st)
                    c.drawLine(22f, 50f, 78f, 50f, st)
                }
                "p:double_tap" -> {
                    fl.alpha = 230
                    c.drawCircle(50f, 50f, 11f, fl)
                    c.drawCircle(50f, 50f, 25f, st)
                    st.alpha = 120
                    c.drawCircle(50f, 50f, 38f, st)
                    st.alpha = 255
                }
                "p:long_press" -> {
                    fl.alpha = 230
                    c.drawCircle(50f, 50f, 14f, fl)
                    arc(c, 20f, 20f, 80f, 80f, -90f, 270f)
                }
                "p:pinch" -> {
                    c.drawCircle(24f, 76f, 7f, fl)
                    c.drawCircle(76f, 24f, 7f, fl)
                    c.drawLine(32f, 68f, 44f, 56f, st)
                    c.drawLine(68f, 32f, 56f, 44f, st)
                }
                "p:pinch_out" -> {
                    c.drawCircle(40f, 60f, 7f, fl)
                    c.drawCircle(60f, 40f, 7f, fl)
                    c.drawLine(34f, 66f, 20f, 80f, st)
                    c.drawLine(66f, 34f, 80f, 20f, st)
                }
                "p:pinch_rotate" -> {
                    c.drawCircle(32f, 62f, 7f, fl)
                    c.drawCircle(68f, 38f, 7f, fl)
                    arc(c, 18f, 18f, 82f, 82f, 200f, 70f)
                    arc(c, 18f, 18f, 82f, 82f, 20f, 70f)
                }
                "scroll_up" -> drawSwipe(c, 1, "up")
                "scroll_down" -> drawSwipe(c, 1, "down")
                "scroll_left" -> drawSwipe(c, 1, "left")
                "scroll_right" -> drawSwipe(c, 1, "right")
                "scroll_top" -> {
                    c.drawLine(22f, 16f, 78f, 16f, st)
                    arrowUp(c, 50f, 84f, 30f)
                }
                "scroll_bottom" -> {
                    c.drawLine(22f, 84f, 78f, 84f, st)
                    c.save()
                    c.rotate(180f, 50f, 50f)
                    arrowUp(c, 50f, 84f, 30f)
                    c.restore()
                }
                "scroll_h" -> {
                    c.save()
                    c.rotate(90f, 50f, 50f)
                    arrowUp(c, 50f, 50f, 16f)
                    arrowUp(c, 50f, 50f, 84f)
                    c.restore()
                }
                "scroll_v" -> {
                    arrowUp(c, 50f, 50f, 16f)
                    arrowUp(c, 50f, 50f, 84f)
                }
                "camera" -> {
                    rr(c, 12f, 30f, 88f, 80f, 10f, st)
                    rr(c, 36f, 20f, 64f, 30f, 4f, st)
                    c.drawCircle(50f, 55f, 14f, st)
                }
                "move_menu" -> {
                    arrowUp(c, 50f, 50f, 14f)
                    arrowUp(c, 50f, 50f, 86f)
                    c.save()
                    c.rotate(90f, 50f, 50f)
                    arrowUp(c, 50f, 50f, 14f)
                    arrowUp(c, 50f, 50f, 86f)
                    c.restore()
                }
                "access_shortcut" -> {
                    c.drawCircle(50f, 50f, 36f, st)
                    c.drawCircle(50f, 32f, 6f, fl)
                    c.drawLine(32f, 46f, 68f, 46f, st)
                    c.drawLine(50f, 46f, 50f, 62f, st)
                    c.drawLine(50f, 62f, 40f, 76f, st)
                    c.drawLine(50f, 62f, 60f, 76f, st)
                }
                "none" -> {
                    st.alpha = 110
                    c.drawCircle(50f, 50f, 28f, st)
                    st.alpha = 255
                }
                else -> drawGesture(c)
            }
        }
    }

    private fun drawGesture(c: Canvas) {
        c.drawCircle(30f, 72f, 9f, fl)
        val p = Path()
        p.moveTo(30f, 72f)
        p.cubicTo(36f, 30f, 66f, 78f, 72f, 30f)
        c.drawPath(p, st)
        c.drawLine(72f, 30f, 62f, 36f, st)
        c.drawLine(72f, 30f, 78f, 42f, st)
    }

    private fun drawFingers(c: Canvas, n: Int) {
        val k = n.coerceIn(1, 5)
        for (i in 0 until k) {
            val x = 50f + (i - (k - 1) / 2f) * 17f
            c.drawCircle(x, 50f, 7f, fl)
        }
    }

    private fun drawSwipe(c: Canvas, n: Int, dir: String) {
        c.save()
        val ang = when (dir) {
            "right" -> 90f
            "down" -> 180f
            "left" -> 270f
            else -> 0f
        }
        c.rotate(ang, 50f, 50f)
        val k = n.coerceIn(1, 5)
        for (i in 0 until k) {
            val x = 50f + (i - (k - 1) / 2f) * 15f
            c.drawCircle(x, 70f, 6f, fl)
        }
        c.drawLine(50f, 56f, 50f, 20f, st)
        c.drawLine(38f, 32f, 50f, 20f, st)
        c.drawLine(62f, 32f, 50f, 20f, st)
        c.restore()
    }
}

/** توزيع الأيقونات في قايمة AssistiveTouch: دايرة (الأول من فوق باتجاه عقارب الساعة) لحد 6، وبعدها شبكة 3×3. */
object MenuGeometry {
    fun offsets(n: Int, radius: Float, step: Float): List<PointF> {
        val out = ArrayList<PointF>()
        if (n <= 0) return out
        if (n == 1) {
            out.add(PointF(0f, 0f))
            return out
        }
        if (n <= 6) {
            for (i in 0 until n) {
                val a = -PI / 2 + i * 2 * PI / n
                out.add(PointF((radius * cos(a)).toFloat(), (radius * sin(a)).toFloat()))
            }
        } else {
            val grid = arrayOf(-1 to -1, 0 to -1, 1 to -1, 1 to 0, 1 to 1, 0 to 1, -1 to 1, -1 to 0)
            for (i in 0 until min(n, 8)) out.add(PointF(grid[i].first * step, grid[i].second * step))
        }
        return out
    }
}

/** إيماءات جاهزة (زي Pinch / Double-Tap / الإيماءات متعددة الأصابع). بتتنفّذ بوضع "اختيار المكان". */
object Presets {

    private fun tap(x: Float, y: Float, off: Long, dur: Long = 50L) =
        Stroke(off, listOf(Pt(x, y, 0L), Pt(x, y, dur)))

    private fun line(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long) =
        Stroke(0L, listOf(Pt(x1, y1, 0L), Pt(x2, y2, dur)))

    fun build(id: String, sw: Int, sh: Int): Gesture? {
        val cx = sw / 2f
        val cy = sh / 2f
        val u = min(sw, sh).toFloat()
        val strokes = ArrayList<Stroke>()

        when {
            id == "p:double_tap" -> {
                strokes.add(tap(cx, cy, 0L))
                strokes.add(tap(cx, cy, 130L))
            }
            id == "p:long_press" -> strokes.add(tap(cx, cy, 0L, 1000L))
            id == "p:pinch" -> {
                val d = u * 0.25f
                strokes.add(line(cx - d, cy - d, cx - d * 0.2f, cy - d * 0.2f, 400L))
                strokes.add(line(cx + d, cy + d, cx + d * 0.2f, cy + d * 0.2f, 400L))
            }
            id == "p:pinch_out" -> {
                val d = u * 0.25f
                strokes.add(line(cx - d * 0.2f, cy - d * 0.2f, cx - d, cy - d, 400L))
                strokes.add(line(cx + d * 0.2f, cy + d * 0.2f, cx + d, cy + d, 400L))
            }
            id == "p:pinch_rotate" -> {
                val r = u * 0.2f
                val a = ArrayList<Pt>()
                val b = ArrayList<Pt>()
                for (i in 0..12) {
                    val ang = i * (PI / 2) / 12
                    val t = (i * 40).toLong()
                    a.add(Pt(cx + r * cos(ang).toFloat(), cy + r * sin(ang).toFloat(), t))
                    b.add(Pt(cx - r * cos(ang).toFloat(), cy - r * sin(ang).toFloat(), t))
                }
                strokes.add(Stroke(0L, a))
                strokes.add(Stroke(0L, b))
            }
            id.startsWith("swipe:") -> {
                val p = id.split(":")
                val n = (p.getOrElse(1) { "1" }.toIntOrNull() ?: 1).coerceIn(1, 5)
                val dir = p.getOrElse(2) { "up" }
                val dist = u * 0.35f
                val spacing = u * 0.09f
                for (i in 0 until n) {
                    val off = (i - (n - 1) / 2f) * spacing
                    when (dir) {
                        "up" -> strokes.add(line(cx + off, cy + dist / 2, cx + off, cy - dist / 2, 350L))
                        "down" -> strokes.add(line(cx + off, cy - dist / 2, cx + off, cy + dist / 2, 350L))
                        "left" -> strokes.add(line(cx + dist / 2, cy + off, cx - dist / 2, cy + off, 350L))
                        else -> strokes.add(line(cx - dist / 2, cy + off, cx + dist / 2, cy + off, 350L))
                    }
                }
            }
            else -> return null
        }
        return Gesture(id, id, strokes, sw, sh, placeMode = true)
    }
}
